import functools
import http.server
import socketserver

PORT = 8934
DIRECTORY = "/Users/abacusindonesia/Documents/OU Reimagining/Claude Code/Repo OO Reimagining"

Handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=DIRECTORY)
socketserver.TCPServer.allow_reuse_address = True

with socketserver.TCPServer(("127.0.0.1", PORT), Handler) as httpd:
    print(f"serving {DIRECTORY} at http://127.0.0.1:{PORT}")
    httpd.serve_forever()
